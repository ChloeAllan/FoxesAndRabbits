
public class FnRMain {

	public static void main(String[] args) {
		ControlFrame cf = new ControlFrame();
		cf.createJFrame();
		
	}
}
