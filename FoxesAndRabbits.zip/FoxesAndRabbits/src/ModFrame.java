import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.TextField;

import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

public class ModFrame extends JPanel implements ActionListener {

	private String[] words;
	private String an;
	private String col;

	public ModFrame() {
		words = new String[2];
	}

	public String getWordTwo() {
		
		return col;
	}

	public String getWordOne() {
		return an;
	}

	public void createFrame() {

		final GraphicsConfiguration graphCon = null;
		JFrame frame2 = new JFrame(graphCon);

		JButton buttonm1, buttonm2;
		frame2.setLayout(new FlowLayout());

		buttonm1 = new JButton("Bears!");
		frame2.add(buttonm1);
		buttonm1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ControlFrame cf = new ControlFrame();
				cf.createJFrame();
				cf.bearPopulate();
			}
		});

		buttonm2 = new JButton("Quit");
		frame2.add(buttonm2);
		buttonm2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});


		TextField text = new TextField("animal _ colour");
		frame2.add(text);
		text.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent z) {
				String input = text.getText();

				words = input.toLowerCase().split(" ");
			
				// System.out.println(an);
				col = words[1];
				
				ControlFrame cf = new ControlFrame();
				
				cf.changeColour();
				
			}
		});

		frame2.setVisible(true);
		frame2.setTitle("Modification Controls");
		frame2.setSize(350, 200);
		frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}

}