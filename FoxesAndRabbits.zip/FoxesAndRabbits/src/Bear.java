import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Bear extends Animal
{

	private static final int MAX_HEALTH = 1000;
    private static final int BREEDING_AGE = 400;
    private static final int MAX_AGE = 800;
    private static final double BREEDING_PROBABILITY = 0.0005;
    private static final int RABBIT_FOOD_VALUE = 2;
    private static final int MAX_LITTER_SIZE = 1;
    private static final Random rand = Randomizer.getRandom();
    
    private int age;
    
    private Bear b;

    private int foodLevel;
    
    private int health;

    public Bear(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
            health = rand.nextInt(MAX_HEALTH);
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
            health = MAX_HEALTH;
        }
    }
    
    public void act(List<Animal> newBears)
    {
        incrementAge();
        decrementHealth();
        if(isAlive()) {
            giveBirth(newBears);            
            // Try to move into a free location.
         // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
            }
    }

    private void decrementHealth() {
    	if(health < 0) {
    		setDead();
    	}
    	else if(rand.nextDouble() <= BREEDING_PROBABILITY) {
        	health = health - 10;
         
        }
    }
    
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    public int getAge()
    {
    	return age;
    }

    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Rabbit) {
                Rabbit rabbit = (Rabbit) animal;
                if(rabbit.isAlive()) { 
                    rabbit.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    // Remove the dead rabbit from the field.
                    return where;
                }
            }
        }
        return null;
        
        }
    
    private void giveBirth(List<Animal> newBears)
    {
        // New bears are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Bear young = new Bear(false, field, loc);
            newBears.add(young);
        }
    }
        
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
    
    public void bearButton() {
    	ControlFrame conFrame = new ControlFrame();
    	conFrame.bearPopulate();	
    }
}
