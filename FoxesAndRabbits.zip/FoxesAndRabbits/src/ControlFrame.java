import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.TextField;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class ControlFrame extends JPanel implements ActionListener {

	private int stepNo;
	private Simulator s;
	private Color anCol;
	private String wordTwo;
	public ControlFrame() {
	}

	public void createJFrame() {
		final GraphicsConfiguration gc = null;
		s = new Simulator();
		
		Timer simTim = new Timer(50, new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				if (stepNo > 0) {
					s.simulateOneStep();
					stepNo = stepNo - 1;

				}
			}
		});

		JFrame frame = new JFrame(gc);
		frame.setLayout(new FlowLayout());
		JButton button, button1, button2, button3, button4, button5;
		
		JPanel panelControl = new JPanel(new GridLayout(3, 2));
	
		button = new JButton("Run Long Simulation");
		button1 = new JButton("Run Short Simulation");
		button2 = new JButton("Reset Sim");
		button3 = new JButton("Step Through Simulation");
		button4 = new JButton("Pause");
		button5 = new JButton("Quit");
		
		panelControl.add(button);
		panelControl.add(button1);
		panelControl.add(button2);
		panelControl.add(button3);
		panelControl.add(button4);
		panelControl.add(button5);
		
		
		JButton button6, button7, button8, button9;
		JPanel panelMod = new JPanel(new GridLayout(3,2));
		
		button6 = new JButton("Bears!");
		button7 = new JButton("Foxes!");
		button8 = new JButton("Rabbits!");
		button9 = new JButton("Humans!");
		
		panelMod.add(button6);
		panelMod.add(button7);
		panelMod.add(button8);
		panelMod.add(button9);
		
		JLabel newColour = new JLabel("New Colour:"); 
		panelMod.add(newColour);
		
		TextField text = new TextField("animal colour");
		panelMod.add(text);
		
		JPanel panel = new JPanel(new GridLayout(2, 1, 5, 5));
		panel.add(panelControl);
		panel.add(panelMod);

		frame.getContentPane().add(panel);
		frame.setVisible(true);
		frame.setTitle("Simulation Controls");
		frame.setSize(400, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent g) {
				stepNo = 4000;
				simTim.start();
				if (stepNo < 0) {
					simTim.stop();
				}
			}
		});
		
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent h) {
				stepNo = 500;
				simTim.start();
				if (stepNo < 0) {
					simTim.stop();
				}
			}
		});
		
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				simTim.stop();
				s.reset();
			}
		});

		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent f) {
				simTim.stop();
				s.simulateOneStep();
			}
		});

		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent i) {
				simTim.stop();
			}
		});
		
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent i) {
				System.exit(1);
			}
		});
		
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent i) {
				s.bearPopulate();
			}
		});
		
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent i) {
				s.foxPopulate();
			}
		}); 
		
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent i) {
				s.rabbitPopulate();
			}
		}); 
		
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent i) {
				s.humanPopulate();
			}
		}); 
		
		// Animal colour
		text.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent z) {
				String input = text.getText();

				String words[] = input.toLowerCase().split(" ");
			
				if (words.length != 2) {
					JOptionPane.showMessageDialog(frame, "Format is animal colour", "Control", JOptionPane.ERROR_MESSAGE); 
				} else {
					String species = words[0];
					Color colour = getAnCol(words[1]); // Lookup the colour of the animal int he colours list
					
					if (colour == null) {
						JOptionPane.showMessageDialog(frame, "Not a colour", "Control", JOptionPane.ERROR_MESSAGE); 
					} else {
						// Update the colour of the animal
						s.changeColour(species, colour, frame);	
					}
				}
			}
		});

	}
	
	public void bearPopulate() {
		s.bearPopulate();
	}
	
	public Color getAnCol(String colour) {
		wordTwo = colour;
		
		if(wordTwo.equals("blue")) {
			anCol = Color.BLUE;
		}
		else if(wordTwo.equals("red")) {
			anCol = Color.RED;
		}
		else if(wordTwo.equals("yellow")) {
			anCol = Color.YELLOW;
		}
		else if(wordTwo.equals("cyan")) {
			anCol = Color.CYAN;
		}
		else if(wordTwo.equals("magenta")) {
			anCol = Color.RED;
		}
		else if(wordTwo.equals("white")) {
			anCol = Color.WHITE;
		}
		else if(wordTwo.equals("black")) {
			anCol = Color.BLACK;
		}
		else if(wordTwo.equals("grey")) {
			anCol = Color.GRAY;
		}
		else if(wordTwo.equals("lightgrey")) {
			anCol = Color.LIGHT_GRAY;
		}		
		else if(wordTwo.equals("darkgrey")) {
			anCol = Color.DARK_GRAY;
		}
		else if(wordTwo.equals("orange")) {
			anCol = Color.ORANGE;
		}
		else if(wordTwo.equals("pink")) {
			anCol = Color.PINK;
		}
		else if (wordTwo.equals("green")) {
			anCol = Color.GREEN;
		}
		else {
			anCol = null;
		}
		return anCol;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub

	}

}