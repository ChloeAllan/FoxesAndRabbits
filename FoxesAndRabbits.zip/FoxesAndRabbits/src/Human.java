import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Human extends Animal {
	// Characteristics shared by all humans (class variables).

	private static final double ILLNESS_PROBABILITY = 0.025;
	private static final int MAX_HEALTH = 500;
	// The age at which a human can start to breed.
	private static final int BREEDING_AGE = 25;
	// The age to which a human can live.
	private static final int MAX_AGE = 500;
	// The likelihood of a human breeding.
	private static final double BREEDING_PROBABILITY = 0.7;
	// The food value of a single rabbit. In effect, this is the
	// number of steps a human can go before it has to eat again.
	private static final int RABBIT_FOOD_VALUE = 5;
	// The maximum number of births.
	private static final int MAX_LITTER_SIZE = 2;
	// A shared random number generator to control breeding.
	private static final Random rand = Randomizer.getRandom();

	// Individual characteristics (instance fields).

	// The human's age.
	private int age;
	// The human's food level, which is increased by eating rabbits.
	private int foodLevel;

	private int health;

	public Human(boolean randomAge, Field field, Location location) {
		super(field, location);
		if (randomAge) {
			age = rand.nextInt(MAX_AGE);
			foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
			health = rand.nextInt(MAX_HEALTH);
		} else {
			age = 0;
			foodLevel = RABBIT_FOOD_VALUE;
			health = MAX_HEALTH;
		}
	}

	public void act(List<Animal> newHumans) {
		incrementAge();
		incrementHunger();
		decrementHealth();
		if (isAlive()) {
			giveBirth(newHumans);
			// Try to move into a free location.
			// Move towards a source of food if found.
			Location newLocation = findFood();
			if (newLocation == null) {
				// No food found - try to move to a free location.
				newLocation = getField().freeAdjacentLocation(getLocation());
				if (newLocation != null) {
					setLocation(newLocation);
				} else {
					// Overcrowding.
					setDead();
				}
			}
		}
	}

	private void decrementHealth() {
		if (health <= 0) {
			setDead();
		} else if (rand.nextDouble() <= ILLNESS_PROBABILITY) {
			health = health - 10;

		}
	}

	private void incrementAge() {
		age++;
		if (age > MAX_AGE) {
			setDead();
		}
	}

	public int getAge() {
		return age;
	}

	private void incrementHunger() {
		foodLevel--;
		if (foodLevel <= 0) {
			setDead();
		}
	}

	private Location findFood() {
		Field field = getField();
		List<Location> adjacent = field.adjacentLocations(getLocation());
		Iterator<Location> it = adjacent.iterator();
		while (it.hasNext()) {
			Location where = it.next();
			Object animal = field.getObjectAt(where);
			if (animal instanceof Rabbit) {
				Rabbit rabbit = (Rabbit) animal;
				if (rabbit.isAlive()) {
					rabbit.setDead();
					foodLevel = RABBIT_FOOD_VALUE;
					// Remove the dead rabbit from the field.
					return where;
				}
			}
		}
		return null;

	}

	private void giveBirth(List<Animal> newHumans) {
		// New humans are born into adjacent locations.
		// Get a list of adjacent free locations.
		Field field = getField();
		List<Location> free = field.getFreeAdjacentLocations(getLocation());
		int births = breed();
		for (int b = 0; b < births && free.size() > 0; b++) {
			Location loc = free.remove(0);
			Human young = new Human(false, field, loc);
			newHumans.add(young);
		}
	}

	private int breed() {
		int births = 0;
		if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
			births = rand.nextInt(MAX_LITTER_SIZE) + 1;
		}
		return births;
	}

	private boolean canBreed() {
		return age >= BREEDING_AGE;
	}
}
